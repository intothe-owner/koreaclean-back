import { Request, Response, Router } from 'express';
import bcrypt from 'bcryptjs';
import { Transaction } from 'sequelize';
import * as jwt from 'jsonwebtoken';
import dotenv from 'dotenv'; 
import { auth } from '../middlewares/auth';
dotenv.config(); // ✅ .env 로드 
type Secret = jwt.Secret; 
type SignOptions = jwt.SignOptions;
//const { Users, Company } = require("../../models");
const { User,Company, sequelize } = require('../../models');
export const router = Router();
const AUTO_LOGIN_ENABLED = String(process.env.AUTO_LOGIN_ENABLED).toLowerCase() === 'true';
const ACCESS_SECRET: Secret = (process.env.JWT_ACCESS_SECRET ?? 'dev-access') as Secret;
const REFRESH_SECRET: Secret = (process.env.JWT_REFRESH_SECRET ?? 'dev-refresh') as Secret;

// SignOptions['expiresIn'] 타입 보장 (string | number)
const ACCESS_EXPIRES_IN = (process.env.JWT_ACCESS_EXPIRES_IN ?? '15m') as SignOptions['expiresIn'];
const REFRESH_EXPIRES_IN = (process.env.JWT_REFRESH_EXPIRES_IN ?? '30d') as SignOptions['expiresIn'];
function cookieOpts(maxAgeMs?: number) {
  const isProd = process.env.NODE_ENV === 'production';
  return {
    httpOnly: true,
    secure: isProd,
    sameSite: 'lax' as const,
    path: '/',
    ...(maxAgeMs ? { maxAge: maxAgeMs } : {}), // undefined면 세션 쿠키
  };
}

function signAccessToken(user: { id: number | string; role?: string; provider?: string }) {
  const payload = { sub: user.id, role: user.role, provider: user.provider ?? 'local' };
  return jwt.sign(payload, ACCESS_SECRET, { expiresIn: ACCESS_EXPIRES_IN });
}

function signRefreshToken(user: { id: number | string }) {
  const payload = { sub: user.id, t: 'refresh' as const };
  return jwt.sign(payload, REFRESH_SECRET, { expiresIn: REFRESH_EXPIRES_IN });
}

//이메일 체크하기
router.get('/check', async (req: any, res: any, next) => {
  try {
    const row = await User.findAndCountAll({
      where: {
        email: req.query.email
      }
    });
    //가입 안 된 것
    if (row.count === 0) {
      res.status(200).json({
        is_success: true,
        exists: false
      })
      //가입된것
    } else {
      res.status(200).json({ 
        is_success: true,
        exists: true
      })
    }
  } catch (error) {
    return res.json({
      is_success: false,
      msg: `${error} 오류 발생`
    })
  }
});

// ✅ 회원 저장 (POST /users/save)
router.post('/save', async (req: Request, res: Response) => { 
  const { email, password, name, phone,role } = req.body ?? {}; 
  console.log(req.body);
 
  // 1) 최소 검증
  const normalizedEmail = (email ?? '').toString().trim().toLowerCase();
  const rawPassword = (password ?? '').toString();
  
  if (!normalizedEmail || !rawPassword) {
    return res.status(400).json({
      is_success: false,
      message: 'email과 password는 필수입니다.',
    });
  }
  // 비밀번호 최소 길이 예시
  if (rawPassword.length < 8) {
    return res.status(400).json({
      is_success: false,
      message: '비밀번호는 8자 이상이어야 합니다.',
    });
  }
  
  let t: Transaction | null = null;

  try {
    t = await sequelize.transaction();

    // 2) 중복 이메일 체크 (unique 인덱스가 있어도 선제 체크)
    const exists = await User.findOne({ where: { email: normalizedEmail }, transaction: t });
    if (exists) {
      await t?.rollback();
      return res.status(409).json({
        is_success: false,
        message: '이미 가입된 이메일입니다.',
      });
    }

    // 3) 비밀번호 해시
    const password_hash = await bcrypt.hash(rawPassword, 10);
    
    // 4) 저장
    const user = await User.create(
      {
        email: normalizedEmail,
        password_hash,
        name: name ? String(name).trim() : null,
        phone: phone ? String(phone).trim() : null,
        role: role ? String(role).trim() : null,

      },
      { transaction: t }
    );
   
    await t?.commit();

    // 5) 민감정보 제거하여 응답
    const { id, createdAt, updatedAt } = user;
    return res.status(201).json({
      is_success: true,
      message: '회원가입이 완료되었습니다.',
      data: { id, email: normalizedEmail, name: user.name, phone: user.phone, createdAt, updatedAt },
    });
  } catch (err: any) {
    if (t) await t.rollback();

    // Unique 제약 위반 등 처리
    if (err?.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({
        is_success: false,
        message: '이미 가입된 이메일입니다.',
      });
    }

    console.error('signup error:', err);
    return res.status(500).json({
      is_success: false,
      message: '회원가입 처리 중 오류가 발생했습니다.',
    });
  }
});
//회원 로그인
router.post('/login', async (req: Request, res: Response) => {
  const { email, password, rememberMe } = req.body ?? {};
  const normalizedEmail = String(email ?? '').trim().toLowerCase();
  const rawPassword = String(password ?? '');

  if (!normalizedEmail || !rawPassword) {
    return res.status(400).json({ is_success: false, message: 'email과 password는 필수입니다.' });
  }

  const user = await User.findOne({ where: { email: normalizedEmail } });
  if (!user) {
    return res.status(401).json({ is_success: false, message: '이메일 또는 비밀번호가 올바르지 않습니다.' });
  }

  const ok = await bcrypt.compare(rawPassword, user.get('password_hash') as string);
  if (!ok) {
    return res.status(401).json({ is_success: false, message: '이메일 또는 비밀번호가 올바르지 않습니다.' });
  }

  // 항상 액세스 토큰은 쿠키로 내려줌(짧게)
  const accessToken = signAccessToken(user);
  res.cookie('access_token', accessToken, cookieOpts( 30 * 60 * 1000)); // 30m
  //res.cookie('access_token', accessToken, cookieOpts( 10000)); // 10s

  // 🔒 자동로그인(리프레시 토큰)은 서버가 허용할 때 + 클라이언트가 rememberMe 동의할 때만
  if (AUTO_LOGIN_ENABLED && rememberMe === true) {
    const refreshToken = signRefreshToken(user);
    const refreshAgeMs = 30 * 24 * 60 * 60 * 1000; // 30일 영속
    res.cookie('refresh_token', refreshToken, cookieOpts(refreshAgeMs));
  } else {
    // 기능 꺼짐이거나 rememberMe=false면 혹시 남아있던 쿠키 제거
    res.clearCookie('refresh_token', { path: '/' });
  }

  return res.json({
    is_success: true,
    message: '로그인 성공',
    data: {
      user: {
        id: user.get('id'),
        email: user.get('email'),
        name: user.get('name'),
        phone: user.get('phone'),
        role: user.get('role'),
        provider: user.get('provider') || 'local',
        createdAt: user.get('createdAt'),
        updatedAt: user.get('updatedAt'),
      },
      // 프론트는 쿠키 기반이므로 토큰 값은 굳이 내려줄 필요 없음
    },
  });
});
/** POST /user/refresh */
router.post('/refresh', async (req: Request, res: Response) => {
  console.log('refresh');
  console.log(AUTO_LOGIN_ENABLED);
  // 🔒 서버가 자동로그인을 허용하지 않으면 리프레시 자체 차단
  if (!AUTO_LOGIN_ENABLED) {
    return res.status(403).json({ is_success: false, message: '자동로그인이 비활성화되어 있습니다.' });
  }
  console.log('refresh1');
  const rt = req.cookies?.refresh_token as string | undefined;
  if (!rt) {
    return res.status(401).json({ is_success: false, message: '리프레시 토큰이 없습니다.' });
  }

  try {
    const decoded = jwt.verify(rt, process.env.JWT_REFRESH_SECRET || 'dev-refresh') as any;
    // 필요시 DB 조회로 유저 상태/권한 반영
    const user = await User.findByPk(decoded.sub);
    if (!user) return res.status(401).json({ is_success: false, message: '유효하지 않은 토큰입니다.' });

    const newAccess = signAccessToken(user);
    res.cookie('access_token', newAccess, cookieOpts(30 * 60 * 1000)); // 15m 재발급

    // (선택) 리프레시 회전 로직: 여기선 단순 재사용
    return res.json({ is_success: true, message: '토큰 갱신', data: { ok: true } });
  } catch (e) {
    console.log(e);
    return res.status(401).json({ is_success: false, message: '리프레시 토큰이 유효하지 않습니다.' });
  }
});
// routes/users.ts (당신 파일에 추가)
router.get('/me',auth(), async (req: Request, res: Response) => {
  try {

    const bearer = req.headers.authorization;
    const fromHeader = bearer?.startsWith('Bearer ') ? bearer.split(' ')[1] : undefined;
    const token = fromHeader || (req.cookies?.access_token as string | undefined);
    
    if (!token) return res.status(401).json({ is_success: false, message: '인증 토큰이 필요합니다.' });

    const decoded = jwt.verify(token, ACCESS_SECRET) as any; // sub, role 등
    const user = await User.findByPk(decoded.sub);
    if (!user) return res.status(401).json({ is_success: false, message: '유효하지 않은 토큰입니다.' });

    return res.json({
      is_success: true,
      data: {
        user: {
          id: user.get('id'),
          email: user.get('email'),
          name: user.get('name'),
          phone: user.get('phone'),
          role: user.get('role'),
          provider: user.get('provider') || 'local',
          createdAt: user.get('createdAt'),
          updatedAt: user.get('updatedAt'),
        },
      },
    });
  } catch (e) {
    console.log('오류')
    return res.status(401).json({ is_success: false, message: '유효하지 않은 토큰입니다.' });
  }
});

/** POST /user/logout */
router.post('/logout', (_req: Request, res: Response) => {
  res.clearCookie('access_token', { path: '/' });
  res.clearCookie('refresh_token', { path: '/' });
  return res.json({ is_success: true, message: '로그아웃 되었습니다.' });
});
router.get("/approv", async (req: Request, res: Response) => {
  try {
    const onlyApproved = ["1", "true", "yes"].includes(
      String(req.query.onlyApproved ?? "").toLowerCase()
    );

    const queryEmail = String(req.query.email ?? "").trim(); 

    // 1) 사용자 식별: req.user → 없으면 email로 조회
    let userId: number | null =
      (req as any).user?.id ?? (req as any).auth?.userId ?? null;
    let userEmail: string | null =
      (req as any).user?.email ?? (req as any).auth?.email ?? null;
    let userName: string | null =
      (req as any).user?.name ?? (req as any).auth?.name ?? null;

    if (!userId) {
      if (!queryEmail) {
        return res
          .status(400)
          .json({ is_success: false, msg: "email 파라미터가 필요합니다." });
      }
      const user = await User.findOne({ where: { email: queryEmail } });
      if (!user) {
        return res
          .status(404)
          .json({ is_success: false, msg: "USER_NOT_FOUND" });
      }
      userId = (user as any).id;
      userEmail = (user as any).email;
      userName = (user as any).name ?? null;
    }

    // 2) 업체 조회 (내 소속 업체)
    const where: any = { owner_user_id: userId };
    if (onlyApproved) {
      where.status = "APPROVED";
    }

    // 최신 수정순으로 정렬, 리스트도 함께 리턴(선택 사항)
    const companies = await Company.findAll({
      where,
      order: [["updatedAt", "DESC"]],
      attributes: ["id", "name", "status"], // 필요 필드만
    });

    // 상태를 소문자 API로 변환 (프론트 타입과 맞춤)
    const normalizeStatus = (s: string) => {
      switch (s) {
        case "PENDING":
          return "submitted";
        case "APPROVED":
          return "approved";
        case "REJECTED":
          return "rejected";
        default:
          return s?.toLowerCase?.() ?? s;
      }
    };

    // onlyApproved 모드인데 승인업체가 없으면 404로
    if (onlyApproved && companies.length === 0) {
      return res.status(404).json({
        is_success: false,
        msg: "NO_APPROVED_COMPANY",
        data: { email: userEmail, name: userName, company: null },
      });
    }

    // 대표(첫 번째) 업체를 data.company로 내려주고, items로 전체도 내려줌
    const head = companies[0] ?? null;

    return res.json({
      is_success: true,
      data: head
        ? {
          email: userEmail,
          name: userName,
          company: {
            id: (head as any).id,
            name: (head as any).name,
            status: normalizeStatus((head as any).status),
          },
        }
        : { email: userEmail, name: userName, company: null },
      items: companies.map((c: any) => ({
        id: c.id,
        name: c.name,
        status: normalizeStatus(c.status),
      })),
    });
  } catch (error: any) {
    console.error("[GET /users/approv] error:", error);
    return res.status(500).json({
      is_success: false,
      msg: error?.message ?? "SERVER_ERROR",
    });
  }
});

router.get('/debug-cookies', (req, res) => {
  console.log('Cookie header:', req.headers.cookie);     // 원문
  console.log('req.cookies:', req.cookies);              // cookie-parser 파싱
  return res.json({ cookies: req.cookies, raw: req.headers.cookie });
});
export default router;