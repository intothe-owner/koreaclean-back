import { Router, Request, Response } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import dotenv from "dotenv";
import { Transaction, Op, WhereOptions, Includeable, Sequelize } from "sequelize";
import * as jwt from 'jsonwebtoken';
import { INTEGER } from "sequelize";
import { sendEmail } from "../lib/mailer";
const { ServiceRequest, Company, User, sequelize, Assignment } = require("../../models");
dotenv.config();
type Secret = jwt.Secret;
const router = Router();
const UPLOAD_DIR = path.join(process.cwd(), "uploads", "request");
const ACCESS_SECRET: Secret = (process.env.JWT_ACCESS_SECRET ?? 'dev-access') as Secret;
// DB ENUM 화이트리스트
// 🔹 상태 ENUM 화이트리스트 (DB와 맞춤)
type DbStatus = "NEW" | "ASSIGNED" | "IN_PROGRESS" | "DONE" | "AS_REQUESTED" | "CANCELLED";

const STATUS_SET = new Set<DbStatus>([
  "NEW", "ASSIGNED", "IN_PROGRESS", "DONE", "AS_REQUESTED", "CANCELLED"
]);
const APPROVED = ["APPROVED"]; // 반드시 배열
type Models = {
  Company: any;
  User?: any;             // Company.associations.owner 가 있을 때만 사용(옵션)
  ServiceRequest: any;    // request_id로 주소 가져올 때 사용
};
// 화면에 보여줄 배정 상태 집합(DECLINED 은 제외)
const VISIBLE_ASSIGN_STATES = ['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS', 'DONE'] as const;
//서비스 타입
const SERVICE_TYPES:any = {
  'REGULAR_1W': '주 1회',
  'REGULAR_2W': '주 2회', 
  'ONE_OFF': '1회성', 
  'SPECIAL': '특수청소'
};
function normalizeSidoShort(sido?: string): string | undefined {
  if (!sido) return undefined;
  let s = sido.trim();

  // 대표적인 축약
  const map: Record<string, string> = {
    "서울특별시": "서울",
    "부산광역시": "부산",
    "대구광역시": "대구",
    "인천광역시": "인천",
    "광주광역시": "광주",
    "대전광역시": "대전",
    "울산광역시": "울산",
    "세종특별자치시": "세종",
    "제주특별자치도": "제주",
  };
  if (map[s]) return map[s];

  // "경상북도" → "경북", "충청남도" → "충남" 등 2글자 축약 시도
  if (s.endsWith("도") && s.length >= 3) {
    const base = s.replace(/도$/, "");
    // 첫 글자 + 마지막 글자 조합 (경상북 → 경북, 충청남 → 충남 등)
    if (base.length >= 2) {
      const head = base[0];
      const tail = base[base.length - 1];
      return `${head}${tail}`;
    }
  }

  // 마지막으로 "시/도" 접미사 제거
  s = s.replace(/(광역시|특별시|특별자치시|특별자치도|자치도|자치시|시|도)$/, "");
  return s || undefined;
}
// "시도>시군구" 후보 생성
function buildRegionCandidates(addressOrPlain?: string): string[] {
  if (!addressOrPlain) return [];

  // 이미 "부산>해운대구" 형태면 그대로 사용
  if (addressOrPlain.includes(">")) {
    const cand = addressOrPlain.split(">").map(s => s.trim()).filter(Boolean);
    if (cand.length === 2) return [`${cand[0]}>${cand[1]}`];
  }

  const { sido, sigungu } = parseKoreanRegion(addressOrPlain);
  const short = normalizeSidoShort(sido);
  const cands: string[] = [];
  if (short && sigungu) cands.push(`${short}>${sigungu}`);

  // 필요 시 시도 전체 키를 쓰는 정책이라면 아래를 사용 (데이터에 "부산>전체" 같은 항목이 있는 경우)
  // if (short) cands.push(`${short}>전체`);

  return cands;
}
// 한글 주소에서 시/도, 구/군 추출 (아주 단순한 규칙 기반)
// 주소에서 시/도, 구/군 추출
function parseKoreanRegion(address?: string): { sido?: string; sigungu?: string } {
  if (!address) return {};
  const toks = address.trim().split(/\s+/);
  if (!toks.length) return {};

  let sido: string | undefined;
  let sigungu: string | undefined;

  // 시/도 후보
  for (const t of toks) {
    if (/(특별시|광역시|특별자치시|특별자치도|시|도)$/.test(t)) { sido = t; break; }
  }
  // 구/군 후보
  for (const t of toks) {
    if (/(구|군)$/.test(t)) { sigungu = t; break; }
  }

  if (!sido) {
    const first = toks[0];
    if (/(시|도)$/.test(first)) sido = first;
  }

  return { sido, sigungu };
}
/**
 * Company.regions(JSON) 이 아래 후보 중 하나라도 포함하면 매칭
 * - `${sido} ${sigungu}`
 * - `${sido}`
 * - (선택) `${sigungu}`  ← 시/도 없이 구만 저장된 케이스까지 허용하려면 활성화
 */
function buildRegionWhereJSON(sequelize: Sequelize, colFullName: string, address?: string) {
  const { sido, sigungu } = parseKoreanRegion(address);
  const candidates: string[] = [];

  if (sido && sigungu) candidates.push(`${sido} ${sigungu}`);
  if (sido) candidates.push(sido);
  // 만약 구 단독 저장을 허용하고 싶다면 주석 해제:
  // if (sigungu) candidates.push(sigungu);

  if (!candidates.length) return undefined;

  // JSON_CONTAINS(company.regions, JSON_QUOTE('부산광역시 해운대구')) = 1
  // Sequelize.where( fn('JSON_CONTAINS', col('company.regions'), JSON.stringify('...')), 1 )
  const orConds = candidates.map((c) =>
    sequelize.where(
      sequelize.fn('JSON_CONTAINS', sequelize.col(colFullName), JSON.stringify(c)),
      1
    )
  );
  return { [Op.or]: orConds };
}
// JSON_CONTAINS(region) WHERE 생성
function whereRegionJson(sequelize: Sequelize, tableName: string, candidates: string[]) {
  if (!candidates.length) return undefined;
  const orConds = candidates.map(c =>
    sequelize.where(
      sequelize.fn("JSON_CONTAINS", sequelize.col(`${tableName}.regions`), JSON.stringify(c)),
      1
    )
  );
  return { [Op.or]: orConds };
}
// 저장소: 절대 경로 + 안전한 파일명
const requestStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      fs.mkdirSync(UPLOAD_DIR, { recursive: true });
      cb(null, UPLOAD_DIR);
    } catch (e) {
      cb(e as any, UPLOAD_DIR);
    }
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || "";
    const name = crypto.randomUUID(); // 충돌 방지
    cb(null, `${name}${ext}`);
  },
});
const requestUpload = multer({
  storage: requestStorage,
  limits: { fileSize: 30 * 1024 * 1024 }, // 30MB
  // fileFilter: (req, file, cb) => {
  //   if (!ALLOWED.has(file.mimetype)) return cb(new Error("허용되지 않는 파일 형식"));
  //   cb(null, true);
  // },
});
// 상태 매핑 (구 UI 호환)
const UI_TO_DB: Record<string, "PENDING" | "APPROVED" | "REJECTED" | undefined> = {
  submitted: "PENDING",
  reviewing: "PENDING", // 별도 상태가 없으므로 PENDING으로 묶음
  approved: "APPROVED",
  rejected: "REJECTED",
};

// Multer 에러 핸들링을 포함한 라우트
router.post("/upload", (req: Request, res: Response, next) => {
  requestUpload.array("file")(req, res, (err: any) => {
    if (err) {
      console.error("[multer error]", err);
      return res.status(400).json({ is_success: false, msg: err.message || "업로드 실패" });
    }
    next();
  });
},
  async (req: any, res: any) => {
    try {
      // 텍스트 필드 확인
      // console.log("BODY:", req.body);  // request_email, service_type, etc.

      const files = (req.files as Express.Multer.File[]) ?? [];

      return res.json({ is_success: true, files });
    } catch (error: any) {
      console.error(error);
      return res.status(500).json({
        is_success: false,
        msg: `업로드 처리 오류: ${error?.message || error}`,
      });
    }
  }
);
//서비스신청 저장하기
router.post("/save", async (req: Request, res: Response) => {
  let tx: Transaction | null = null;
  try {
    console.log(req.body);
    const bearer = req.headers.authorization;
    const fromHeader = bearer?.startsWith('Bearer ') ? bearer.split(' ')[1] : undefined;
    const token = fromHeader || (req.cookies?.access_token as string | undefined);

    if (!token) return res.status(401).json({ is_success: false, message: '인증 토큰이 필요합니다.' });

    const decoded = jwt.verify(token, ACCESS_SECRET) as any; // sub, role 등
    const user = await User.findByPk(decoded.sub);
    if (!user) return res.status(401).json({ is_success: false, message: '유효하지 않은 토큰입니다.' });
    console.log(user?.get('id'));
    const created_by = user?.get('id');
    if (!created_by) {
      return res.status(401).json({ is_success: false, msg: "인증 필요: created_by 없음" });
    }
    const {
      org_name,
      contact_name,
      contact_phone,
      contact_email,
      address,
      service_type,
      preferred_datetime,
      details,
      attachments
    } = req.body ?? {};
    const normalizeDigits = (s: any) =>
      typeof s === "string" ? s.replace(/\D/g, "") : null;
    const normalizedPhone = contact_phone ? normalizeDigits(contact_phone) : null;
    const payload = {
      org_name: org_name,
      contact_name,
      contact_phone: normalizedPhone,
      address,
      contact_email,
      service_type,
      preferred_datetime,
      details,
      attachments,
      status: 'NEW',
      created_by
    }
    console.log('payload', payload);

    tx = await sequelize.transaction();
    const created = await ServiceRequest.create(payload as any, { Transaction: tx });
    if (tx) await tx.commit();
    sendEmail({
      to:'kimnamhyong@gmail.com',
      subject:`${org_name}에서 서비스 신청을 하였습니다.`,
      html:`
        담당자 : ${org_name}<br/>
        기관명 : ${contact_name}<br/>
        연락처 : ${contact_phone}<br/>
        서비스 종류 : ${SERVICE_TYPES[service_type]}<br/>
      `
    })
    return res.json({ is_success: true, data: created });
  } catch (error: any) {
    if (tx) await tx.rollback();
    console.error("[/api/company/save] error:", error);
    return res.status(500).json({
      is_success: false,
      msg: error?.message ?? "서버 오류",
    });
  }
});
//서비스 신청 목록
// 서비스 신청 목록
router.get("/list", async (req: Request, res: Response) => {
  try {
    const page = Math.max(1, parseInt(String(req.query.page) ?? "1", 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(String(req.query.pageSize ?? "10"), 10) || 10));
    const q = String(req.query.q ?? "").trim();
    const status = (req.query.status ?? "").toString().trim().toUpperCase();
    const from = (req.query.from ?? "").toString().trim(); // YYYY-MM-DD
    const to = (req.query.to ?? "").toString().trim();     // YYYY-MM-DD

    // ✅ 내 신청만 보기 옵션
    const mineOnly = String(req.query.mine ?? "").trim() === "1";
    const requestEmail = String(req.query.request_email ?? "").trim();

    // where 절 구성 (AND 조건 모으기)
    const andConds: WhereOptions[] = [];

    // 상태 필터 (ENUM만 허용)
    if (status && STATUS_SET.has(status as any)) {
      andConds.push({ status });
    }

    // 기간 필터: createdAt 기준 (inclusive)
    if (from || to) {
      const range: any = {};
      if (from) range[Op.gte] = new Date(`${from}T00:00:00.000Z`);
      if (to)   range[Op.lte] = new Date(`${to}T23:59:59.999Z`);
      andConds.push({ createdAt: range });
    }

    // 검색어: 부분 일치
    if (q) {
      const like = `%${q}%`;
      andConds.push({
        [Op.or]: [
          { org_name:      { [Op.like]: like } },
          { contact_name:  { [Op.like]: like } },
          { contact_phone: { [Op.like]: like } },
          { contact_email: { [Op.like]: like } },
          { address:       { [Op.like]: like } },
        ],
      });
    }

    // ✅ 내 신청만 (우선순위 1)
    // 인증 미들웨어에서 req.user?.id / req.user?.email 을 세팅했다고 가정
    const meId = (req as any)?.user?.id as number | undefined;
    console.log('meId',meId);
    const meEmail = (req as any)?.user?.email as string | undefined;

    if (mineOnly && meId) {
      andConds.push({ created_by: meId });
    }
    // ✅ 특정 이메일의 신청만 (우선순위 2)
    else if (requestEmail) {
      // 1) 해당 이메일의 사용자 id를 찾고(created_by 매칭), 2) 신청서 contact_email 도 매칭
      const owner = await User.findOne({
        where: { email: requestEmail },
        attributes: ["id"],
        paranoid: false,
      });

      const orConds: WhereOptions[] = [{ contact_email: requestEmail }];
      if (owner?.id) {
        orConds.push({ created_by: owner.id });
      }

      andConds.push({ [Op.or]: orConds });
    }
    // (옵션) 인증되어 있고, 관리자/슈퍼가 아니면 기본적으로 자기 것만 보게 강제하려면 여기서 meId를 적용
    // else if (meId && (req as any).user.role === 'CLIENT') {
    //   andConds.push({ created_by: meId });
    // }

    const where: WhereOptions =
      andConds.length > 0 ? { [Op.and]: andConds } : {};

    const offset = (page - 1) * pageSize;

    const { rows, count } = await ServiceRequest.findAndCountAll({
      where,
      order: [["id", "DESC"]],
      offset,
      limit: pageSize,
      include: [
        {
          model: Assignment,
          as: "assignments",
          required: false,
          where: { status: { [Op.in]: VISIBLE_ASSIGN_STATES } }, // ['ASSIGNED','ACCEPTED','IN_PROGRESS','DONE']
          include: [
            { model: Company, as: "company" },
            // ⛏️ alias 교정: 관리자 노출 X 정책이므로 assignee만 사용
            { model: User, as: "assigner", attributes: ["id", "name", "email", "phone"] },
          ],
          // ✅ 최근 배정 1건만
          separate: true,
          limit: 1,
          order: [["assigned_at", "DESC"]],
        },
      ],
    });

    // 응답 가공
    const items = rows.map((r: any) => {
      const plain = r.get({ plain: true });
      const a = Array.isArray(plain.assignments) ? plain.assignments[0] : null;

      const assignedCompany = a?.company
        ? {
            id: a.company.id,
            email: a.assignee?.email ?? a.assignee_email ?? "",
            company: a.company.name ?? "",
            ceo: a.company.ceo ?? "",
            phone: a.company.phone ?? "",
            resources: a.company.resources ?? null,
            certs: a.company.certs ?? null, // 배열/문자열 혼재 대응은 프런트에서 처리
            status: a.company.status,
          }
        : null;

      const response_email = a?.assignee?.email ?? a?.assignee_email ?? null;

      delete plain.assignments;
      return { ...plain, response_email, assignedCompany };
    });

    const total = count;
    const totalPages = Math.max(Math.ceil(total / pageSize), 1);

    return res.json({
      is_success: true,
      items,
      page,
      pageSize,
      total,
      totalPages,
    });
  } catch (error: any) {
    console.error("[GET /request/list] error:", error);
    return res.status(500).json({
      is_success: false,
      message: "목록 조회 실패",
      error: error.message,
    });
  }
});

router.post('/status', async (req: Request, res: Response) => {
  try {
    const { id, status } = req.body as { id?: number; status?: DbStatus };

    if (!id || !status) {
      return res.status(400).json({ is_success: false, message: 'id와 status가 필요합니다.' });
    }
    if (!STATUS_SET.has(status)) {
      return res.status(400).json({ is_success: false, message: '허용되지 않는 상태 값입니다.' });
    }

    const sr = await ServiceRequest.findByPk(id);
    if (!sr) {
      return res.status(404).json({ is_success: false, message: '서비스 신청을 찾을 수 없습니다.' });
    }

    const result = await sequelize.transaction(async (t: Transaction) => {
      // 최근 활성 배정 1건
      const latestActive = await Assignment.findOne({
        where: {
          service_request_id: id,
          status: { [Op.in]: VISIBLE_ASSIGN_STATES as any },
        },
        order: [
          ['assigned_at', 'DESC'],
          ['id', 'DESC'],
        ],
        transaction: t,
      });

      // 상태 전이 정책에 따른 Assignment 동기화
      switch (status) {
        case 'NEW':
        case 'CANCELLED': {
          // 활성 배정 전부 DECLINED 처리
          await Assignment.update(
            { status: 'DECLINED' },
            {
              where: {
                service_request_id: id,
                status: { [Op.in]: VISIBLE_ASSIGN_STATES as any },
              },
              transaction: t,
            }
          );
          break;
        }

        case 'ASSIGNED': {
          if (latestActive) {
            await latestActive.update({ status: 'ASSIGNED' }, { transaction: t });
          }
          break;
        }

        case 'IN_PROGRESS': {
          if (latestActive) {
            await latestActive.update({ status: 'IN_PROGRESS' }, { transaction: t });
          }
          break;
        }

        case 'DONE': {
          if (latestActive) {
            await latestActive.update({ status: 'DONE' }, { transaction: t });
          }
          break;
        }

        case 'AS_REQUESTED': {
          // 배정 상태는 그대로 두고 SR만 변경
          break;
        }
      }

      // SR 상태 업데이트
      await sr.update({ status }, { transaction: t });

      // 응답용 재조회(원하면 include 추가 가능)
      const fresh = await ServiceRequest.findByPk(id, { transaction: t });

      return { serviceRequest: fresh, latestActiveId: latestActive?.id ?? null };
    });

    return res.json({
      is_success: true,
      item: {
        serviceRequest: result.serviceRequest?.get({ plain: true }),
        latestActiveId: result.latestActiveId,
      },
    });
  } catch (error: any) {
    console.error('[POST /request/status] error:', error);
    return res.status(500).json({ is_success: false, message: '업데이트 실패', error: error.message });
  }
});
//배정업체 보기
router.get("/companies", async (req: Request, res: Response) => {
  try {
    const q = ((req.query.q as string) ?? "").trim();
    const limit = Math.min(Math.max(parseInt((req.query.limit as string) ?? "20", 10) || 20, 1), 100);
    const offset = Math.max(parseInt((req.query.offset as string) ?? "0", 10) || 0, 0);

    // 지역 기준: request_id(신청 주소 자동 사용) 또는 region(직접 전달)
    const requestId = req.query.request_id ? Number(req.query.request_id) : undefined;
    const regionText = ((req.query.region as string) ?? "").trim();

    // 기본 회사 조건(승인)
    const whereCompany: WhereOptions = { status: { [Op.in]: APPROVED } };

    // q 검색
    if (q) {
      const like = { [Op.substring]: q };
      (whereCompany as any)[Op.or] = [
        { name: like },
        { ceo: like },
        { biz_no: like },
        { phone: like },
        { address: like },
      ];
      const qNum = Number(q);
      if (Number.isInteger(qNum)) (whereCompany as any)[Op.or].push({ id: qNum });
    }

    // 지역 후보 생성
    let addressForRegion: string | undefined = regionText || undefined;
    if (!addressForRegion && requestId) {
      const sr = await ServiceRequest.findByPk(requestId, { attributes: ["id", "address"] });
      addressForRegion = sr?.address;
    }
    const candidates = buildRegionCandidates(addressForRegion);

    // 테이블명 안전 추출
    const tn = Company.getTableName();
    const tableName = typeof tn === "string" ? tn : tn.tableName;

    // JSON_CONTAINS 조건 추가
    if (candidates.length) {
      const jsonWhere = whereRegionJson(Company.sequelize!, tableName, candidates);
      if (jsonWhere) Object.assign(whereCompany, jsonWhere);
    }

    // owner 조인(있을 때만)
    const include: Includeable[] =
      Company?.associations?.owner && User
        ? [
          {
            model: User,
            as: "owner",
            required: false,
            attributes: ["id", "name", "email", "phone"],
            ...(q
              ? {
                where: {
                  [Op.or]: [
                    { name: { [Op.substring]: q } },
                    { email: { [Op.substring]: q } },
                    { phone: { [Op.substring]: q } },
                  ],
                },
              }
              : {}),
          },
        ]
        : [];

    const { rows, count } = await Company.findAndCountAll({
      where: whereCompany,
      include,
      order: [["id", "DESC"]],
      offset,
      limit,
    });

    // 응답 매핑 (프론트 포맷 유지)
    const items = rows.map((c: any) => {
      const owner = c.owner || {};
      return {
        company_id: c.id,
        company_name: c.name ?? "",
        company_phone: c.phone ?? "",
        address_postcode: "",
        address1: c.address ?? "",
        address2: "",
        email: owner.email ?? "",
        name: owner.name ?? "",
        mobile: owner.phone ?? "",
      };
    });

    return res.json({ is_success: true, items, total: count });
  } catch (error: any) {
    console.error("[GET /request/companies] error:", error);
    return res.status(500).json({
      is_success: false,
      message: "업체 목록 조회 실패",
      error: error.message,
    });
  }
});

/** 배정 */
router.post('/assign', async (req: Request, res: Response) => {
  const { id, assignee_email, company,notes } = req.body;
  console.log(req.body);
  if (!id || !assignee_email) {
    return res.status(400).json({ is_success: false, message: 'id와 assignee_email이 필요합니다.' });
  }

  try {
    const sr = await ServiceRequest.findByPk(id);
    if (!sr) return res.status(404).json({ is_success: false, message: '서비스 신청을 찾을 수 없습니다.' });

    const user = await User.findOne({ where: { email: assignee_email } });
    if (!user) return res.status(404).json({ is_success: false, message: '해당 이메일의 회원이 없습니다.' });

    
    // 소속 업체 승인 체크
    const companyId = company.company_id;

    if (!companyId) {
      return res.status(400).json({ is_success: false, message: '담당자가 업체에 소속되어 있지 않습니다.' });
    }
    const comp = await Company.findByPk(companyId);

    if (!comp) return res.status(400).json({ is_success: false, message: '회원의 회사 정보를 찾을 수 없습니다.' });
    if (String((comp as any).status).toUpperCase() !== 'APPROVED') {
      return res.status(400).json({ is_success: false, message: '승인된 업체가 아닙니다.' });
    }

    const created = await sequelize.transaction(async (t: Transaction) => {
      // 기존 활성 배정 종료
      await Assignment.update(
        { status: 'DECLINED' },
        {
          where: {
            service_request_id: id,
            status: { [Op.in]: ['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS'] },
          },
          transaction: t,
        }
      );

      // // 새 배정 생성 (관리자 ID 저장 없음)
      const a = await Assignment.create(
        {
          service_request_id: id,
          company_id: companyId,
          assigned_by: (user as any).id,
          status: 'ASSIGNED',
          assigned_at: new Date(),
          notes: notes ?? null,
        },
        { transaction: t }
      );

      // SR 상태 동기화
      await sr.update({ status: 'ASSIGNED' }, { transaction: t });

      // include에서 assigner 제거
      const full = await Assignment.findByPk(a.id, {
        include: [
          { model: Company, as: 'company' },
          { model: User, as: 'assigner' },
          { model: ServiceRequest, as: 'serviceRequest' },
        ],
        transaction: t,
      });

      return full;
    });

    return res.json({ is_success: true, item: created });
  } catch (err: any) {
    console.error('[POST /request/assign] error:', err);
    return res.status(500).json({ is_success: false, message: '배정 실패', error: err.message });
  }
});

/** 배정 해제 */
 /** 배정 해제 */
router.post('/unassign', async (req: Request, res: Response) => {
  const { id } = req.body as { id?: number };
  if (!id) {
    return res.status(400).json({ is_success: false, message: 'id가 필요합니다.' });
  }

  try {
    const sr = await ServiceRequest.findByPk(id);
    if (!sr) {
      return res.status(404).json({ is_success: false, message: '서비스 신청을 찾을 수 없습니다.' });
    }

    // (선택) 진행/완료 보호: 진행 중/완료면 해제 금지 — UI에서 막고 있지만 백엔드에서도 한 번 더 가드
    const srStatus = String((sr as any).status || '').toUpperCase();
    if (srStatus === 'IN_PROGRESS' || srStatus === 'DONE') {
      return res.status(400).json({ is_success: false, message: '진행/완료 상태에서는 배정 해제가 불가합니다.' });
    }

    const result = await sequelize.transaction(async (t: Transaction) => {
      // 1) 활성 배정들을 DECLINED 처리
      const [affected] = await Assignment.update(
        { status: 'DECLINED' },
        {
          where: {
            service_request_id: id,
            status: { [Op.in]: ['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS'] },
          },
          transaction: t,
        }
      );

      // 2) SR 상태를 NEW로 되돌림 (정책에 맞게 조정 가능)
      await sr.update({ status: 'NEW' }, { transaction: t });

      // 3) 응답을 위해 최신 상태 재조회 (include는 선택)
      const freshSr = await ServiceRequest.findByPk(id, { transaction: t });

      return { affected, freshSr };
    });

    return res.json({
      is_success: true,
      item: {
        // 프론트에서 쓰는 형태(UnassignResp)와 맞춤
        serviceRequest: result.freshSr?.get({ plain: true }) ?? { id, status: 'NEW' },
        declined_count: result.affected, // 참고용
      },
    });
  } catch (err: any) {
    console.error('[POST /request/unassign] error:', err);
    return res.status(500).json({ is_success: false, message: '배정 해제 실패', error: err.message });
  }
});

// 배정 상태 변경
router.post('/assign/:assignmentId/status', async (req: Request, res: Response) => {
  const { assignmentId } = req.params;
  const { status } = req.body as { status?: 'ASSIGNED' | 'ACCEPTED' | 'DECLINED' | 'IN_PROGRESS' | 'DONE' };

  if (!status) return res.status(400).json({ is_success: false, message: 'status가 필요합니다.' });

  try {
    const a = await Assignment.findByPk(assignmentId);
    if (!a) return res.status(404).json({ is_success: false, message: '배정을 찾을 수 없습니다.' });

    await sequelize.transaction(async (t: any) => {
      await a.update({ status }, { transaction: t });

      // SR 동기화 정책 (원하는 정책으로 변경 가능)
      const sr = await ServiceRequest.findByPk((a as any).service_request_id, { transaction: t });
      if (sr) {
        const map: Record<string, string> = {
          ASSIGNED: 'ASSIGNED',
          ACCEPTED: 'ASSIGNED',    // SR 레벨은 ASSIGNED 유지하거나 'IN_PROGRESS'로 승격 등 정책 결정
          IN_PROGRESS: 'IN_PROGRESS',
          DONE: 'DONE',
          DECLINED: 'ASSIGNED',    // 다른 배정이 있을 수 있으니 SR은 그대로 두거나 재배정 대기 상태로…(정책)
        };
        const next = map[status] ?? 'ASSIGNED';
        await sr.update({ status: next }, { transaction: t });
      }
    });

    const full = await Assignment.findByPk(assignmentId, {
      include: [
        { model: Company, as: 'company' },
        { model: User, as: 'assigner' },
        { model: ServiceRequest, as: 'serviceRequest' },
      ],
    });

    return res.json({ is_success: true, item: full });
  } catch (err: any) {
    console.error('[POST /assign/:id/status] error:', err);
    return res.status(500).json({ is_success: false, message: '상태 변경 실패', error: err.message });
  }
});
export default router;