import { Router, Request, Response } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import dotenv from "dotenv";
import { Transaction,Op, WhereOptions } from "sequelize";
import * as jwt from 'jsonwebtoken';
import { sendEmail } from "../lib/mailer";
import { auth } from "../middlewares/auth";
const { Company, User, ServiceRequest, Assignment, sequelize } = require("../../models");

dotenv.config();
type Secret = jwt.Secret; 
const router = Router();
const UPLOAD_DIR = path.join(process.cwd(), "uploads", "company");
const ACCESS_SECRET: Secret = (process.env.JWT_ACCESS_SECRET ?? 'dev-access') as Secret;
// 저장소: 절대 경로 + 안전한 파일명
const companyStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        try {
            fs.mkdirSync(UPLOAD_DIR, { recursive: true });
            cb(null, UPLOAD_DIR);
        } catch (e) {
            cb(e as any, UPLOAD_DIR);
        }
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname) || "";
        const name = crypto.randomUUID(); // 충돌 방지
        cb(null, `${name}${ext}`);
    },
});
const companyUpload = multer({
    storage: companyStorage,
    limits: { fileSize: 30 * 1024 * 1024 }, // 30MB
    // fileFilter: (req, file, cb) => {
    //   if (!ALLOWED.has(file.mimetype)) return cb(new Error("허용되지 않는 파일 형식"));
    //   cb(null, true);
    // },
});
// 상태 매핑 (구 UI 호환)
const UI_TO_DB: Record<string, "PENDING"|"APPROVED"|"REJECTED" | undefined> = {
  submitted: "PENDING",
  reviewing: "PENDING", // 별도 상태가 없으므로 PENDING으로 묶음
  approved:  "APPROVED",
  rejected:  "REJECTED",
};
// 업체 화면에서 노출할 배정 상태(활성 + 완료) — DECLINED은 숨김
const VISIBLE_ASSIGN_STATES = ['ASSIGNED','ACCEPTED','IN_PROGRESS','DONE'] as const;

// 프런트 상태 ↔ DB(ServiceRequest) 상태 매핑
// front: 'wait' | 'progress' | 'complete' | 'cancel'
// db:    'ASSIGNED' | 'IN_PROGRESS' | 'DONE' | 'CANCELLED'
const frontToDbSR: Record<'wait'|'progress'|'complete'|'cancel', 'ASSIGNED'|'IN_PROGRESS'|'DONE'|'CANCELLED'> = {
  wait: 'ASSIGNED',
  progress: 'IN_PROGRESS',
  complete: 'DONE',
  cancel: 'CANCELLED',
};
const dbSRToFront = (s: string): 'wait'|'progress'|'complete'|'cancel' => {
  switch ((s || '').toUpperCase()) {
    case 'ASSIGNED':    return 'wait';
    case 'IN_PROGRESS': return 'progress';
    case 'DONE':        return 'complete';
    case 'CANCELLED':   return 'cancel';
    default:            return 'wait'; // NEW/AS_REQUESTED 등은 업체화면에선 대기 취급
  }
};

// (옵션) 서비스 유형 매핑 — 필요 시 조정
const dbTypeToFront = (t?: string): 'regular'|'oneoff'|'special' => {
  switch ((t || '').toUpperCase()) {
    case 'ONE_OFF': return 'oneoff';
    case 'SPECIAL': return 'special';
    default:        return 'regular'; // REGULAR_1W/2W → regular 로 뭉침
  }
};

// 로그인 사용자 → 승인된 소유 회사 id 찾기
async function getApprovedCompanyIdByUser(req: Request): Promise<number> {
  const bearer = req.headers.authorization;
  const fromHeader = bearer?.startsWith('Bearer ') ? bearer.split(' ')[1] : undefined;
  const token = fromHeader || (req as any).cookies?.access_token;
  if (!token) throw new Error('UNAUTHORIZED');

  const decoded = jwt.verify(token, ACCESS_SECRET) as any; // sub 포함
  const me = await User.findByPk(decoded.sub);
  if (!me) throw new Error('UNAUTHORIZED');

  const comp = await Company.findOne({
    where: { owner_user_id: me.id, status: 'APPROVED' },
    attributes: ['id'],
  });
  if (!comp) throw new Error('NO_APPROVED_COMPANY');
  return comp.id as number;
}
// Multer 에러 핸들링을 포함한 라우트
router.post("/upload", (req: Request, res: Response, next) => {
    companyUpload.array("file")(req, res, (err: any) => {
        if (err) {
            console.error("[multer error]", err);
            return res.status(400).json({ is_success: false, msg: err.message || "업로드 실패" });
        }
        next();
    });
},
    async (req: any, res: any) => {
        try {
            // 텍스트 필드 확인
            // console.log("BODY:", req.body);  // request_email, service_type, etc.

            const files = (req.files as Express.Multer.File[]) ?? [];

            return res.json({ is_success: true, files });   
        } catch (error: any) {
            console.error(error);
            return res.status(500).json({  
                is_success: false,
                msg: `업로드 처리 오류: ${error?.message || error}`,
            });
        }
    }
);
//업체 저장하기
router.post("/save", async (req: Request, res: Response) => {
  let tx: Transaction | null = null;
  try {
    // 1) owner_user_id 가져오기 (프로젝트의 인증 구조에 맞게 수정)
    // - 예: passport/jwt 미들웨어에서 넣는 경우: req.user?.id
    // - 또는 커스텀 미들웨어: req.auth?.userId
    // - 최후 수단으로 body에서 받기 (신뢰도 낮음 → 가능하면 막으세요)
    const bearer = req.headers.authorization;
    const fromHeader = bearer?.startsWith('Bearer ') ? bearer.split(' ')[1] : undefined;
    const token = fromHeader || (req.cookies?.access_token as string | undefined);

    if (!token) return res.status(401).json({ is_success: false, message: '인증 토큰이 필요합니다.' });

    const decoded = jwt.verify(token, ACCESS_SECRET) as any; // sub, role 등
    const user = await User.findByPk(decoded.sub);
    if (!user) return res.status(401).json({ is_success: false, message: '유효하지 않은 토큰입니다.' });
    console.log(user?.get('id'));
    const owner_user_id = user?.get('id');
    if (!owner_user_id) {
      return res.status(401).json({ is_success: false, msg: "인증 필요: owner_user_id 없음" });
    }

    // 2) 입력 파라미터 파싱
    const {
      name,
      ceo = null,
      biz_no = null,
      phone = null,
      address = null,
      regions = null,
      equipments = null,
      certs = null,
      documents = null,
      status = "PENDING",
    } = req.body ?? {};

    if (!name || typeof name !== "string") {
      return res.status(400).json({ is_success: false, msg: "name은 필수입니다." });
    }

    // 3) 포맷 정리: "-" 제거한 숫자만 저장하고 싶으면 여기서 정규화
    const normalizeDigits = (s: any) =>
      typeof s === "string" ? s.replace(/\D/g, "") : null;

    const normalizedBizNo = biz_no ? normalizeDigits(biz_no) : null;   // 예: "1234567890"
    const normalizedPhone = phone ? normalizeDigits(phone) : null; 
       // 예: "01012345678"

    // 4) 배열/JSON 정리: 빈 배열은 null로
    const orNullArray = (arr: any) =>
      Array.isArray(arr) && arr.length > 0 ? arr : null;

    const payload = {
      name: String(name).trim(),
      ceo: ceo ?? null,
      biz_no: normalizedBizNo ?? null,
      phone: normalizedPhone ?? null,
      address: address ?? null,
      regions: orNullArray(regions),
      equipments: orNullArray(equipments),
      certs: orNullArray(certs),
      documents: orNullArray(documents),
      status: status ?? "PENDING",
      owner_user_id, // 🔹 요구하신 회원 고유번호
    };

    // 5) 트랜잭션으로 생성
    tx = await sequelize.transaction();
    const created = await Company.create(payload as any, { transaction: tx });
    
    sendEmail({
          to:'kimnamhyong@gmail.com',
          subject:`${name}에서 업체등록 신청을 하였습니다.`,
          html:`
            업체명 : ${name}<br/>
            대표 : ${ceo}<br/>
            연락처 : ${phone}<br/>
            서비스 지역 : ${orNullArray(regions)}<br/>
          `
        })
    if(tx) await tx.commit();

    return res.json({ is_success: true, data: created });
  } catch (error: any) {
    if (tx) await tx.rollback();
    console.error("[/api/company/save] error:", error);
    return res.status(500).json({
      is_success: false,
      msg: error?.message ?? "서버 오류",
    });
  }
});
//업체 목록
router.get("/list", async (req: Request, res: Response) => {
  try {
    // 1) 파라미터 파싱
    const page       = Math.max(1, parseInt(String(req.query.page ?? "1"), 10) || 1);
    const pageSize   = Math.min(100, Math.max(1, parseInt(String(req.query.pageSize ?? "10"), 10) || 10));
    const q          = String(req.query.q ?? "").trim();
    const statusRaw  = String(req.query.status ?? "all").toUpperCase();
    const sortByRaw  = String(req.query.sortBy ?? "createdAt");
    const sortDirRaw = String(req.query.sortDir ?? "DESC").toUpperCase();

    // 2) 정렬 안전화
    const ALLOWED_SORT = new Set(["createdAt", "name", "status"]);
    const sortBy  = ALLOWED_SORT.has(sortByRaw) ? sortByRaw : "createdAt";
    const sortDir = sortDirRaw === "ASC" ? "ASC" : "DESC";

    // 3) 상태 필터 (DB/구 UI 모두 허용)
    let statusFilter: "PENDING" | "APPROVED" | "REJECTED" | undefined;
    if (statusRaw !== "ALL") {
      // DB enum 값이면 그대로, 아니면 UI 값 매핑
      if (["PENDING","APPROVED","REJECTED"].includes(statusRaw)) {
        statusFilter = statusRaw as any;
      } else {
        const mapped = UI_TO_DB[statusRaw.toLowerCase()];
        if (mapped) statusFilter = mapped;
      }
    }

    // 4) where 구성
    const where: WhereOptions = {};
    if (statusFilter) {
      where["status"] = statusFilter;
    }
    if (q) {
      // MySQL은 LIKE가 기본적으로 case-insensitive, PG면 iLike 사용 고려
      const like = `%${q}%`;
      Object.assign(where, {
        [Op.or]: [
          { name:  { [Op.like]: like } },
          { ceo:   { [Op.like]: like } },
          { biz_no:{ [Op.like]: like } },
          { phone: { [Op.like]: like } },
        ],
      });
    }

    // 5) 조회
    const offset = (page - 1) * pageSize;
    const { rows, count } = await Company.findAndCountAll({
      where,
      order: [[sortBy, sortDir]],
      limit: pageSize,
      offset,
    });

    // 6) 응답 매핑 (프론트 CompanyRow 모양)
    //    - attachments.files: documents[].url만 추출 (절대/상대 URL은 저장 방식에 따라 다름)
    const items = rows.map((r: any) => {
      const docs = Array.isArray(r.documents) ? r.documents : [];
      const files = docs
        .map((d: any) => d?.url)
        .filter((u: any) => typeof u === "string" && u.length > 0);

      // 구 UI에서 쓰는 status 라벨로도 보고 싶으면 여기서 변환 가능
      // const statusUi = r.status === "PENDING" ? "submitted"
      //                 : r.status === "APPROVED" ? "approved"
      //                 : "rejected";

      return {
        id: r.id,
        createdAt: r.createdAt?.toISOString?.() ?? r.createdAt, // ISO string
        company: r.name,
        ceo: r.ceo ?? "",
        bizno: r.biz_no ?? "",
        phone: r.phone ?? "",
        equipments:Array.isArray(r.equipments) ? r.equipments : [],
        certs:Array.isArray(r.certs) ? r.certs : [],
        areas: Array.isArray(r.regions) ? r.regions : [],
        status: r.status, // "PENDING" | "APPROVED" | "REJECTED"
        attachments: files.length ? { files } : null,
        address: r.address ?? null,
        
      };
    });

    const total = count;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));

    return res.json({
      is_success: true,
      page,
      pageSize,
      total,
      totalPages,
      items,
    });
  } catch (error: any) {
    console.error("[GET /company/list] error:", error);
    return res.status(500).json({
      is_success: false,
      msg: error?.message ?? "서버 오류",
    });
  }
});
router.post('/status', async (req:Request,res:Response,next) => {
  try {
    
    const {id,status} = req.body??{};
    
    await Company.update({
      status
    },{
      where:{
        id
      }
    });
    return res.json({ is_success: true, msg:'업데이트 성공' });
  } catch (error) {
    console.error(error);
    return res.json({ is_success: false, msg:'업데이트 실패' });
  }
})
// GET /users/companies?email=...&status=APPROVED
router.get('/companies', async (req, res) => {
  try {

    const { email } = req.query ;

  if (!email) return res.status(400).json({ is_success:false, msg:'email required' });

  // 1) email -> user 조회
  const user = await User.findOne({ where: { email } });
  if (!user) return res.status(404).json({ is_success:false, msg:'user not found' });

  // 2) 유저가 소속된 회사 목록 조인(프로젝트 스키마에 맞게)
  // 예) UserCompany(유저-회사 매핑 테이블) 기준으로 조회
  const companies = await Company.findAll({
    
    where:{
      owner_user_id:user.id,
      status:'APPROVED'
    },
    attributes: ['id','name','status'],
    order: [['name','ASC']],
  });
  console.log(companies);

  return res.json({ is_success:true, items: companies });
  } catch (error) {
    return res.json({ is_success:true, msg: error });
  }
  
});
// 배정된 서비스 신청 목록(업체 전용)
router.get('/requests', async (req: Request, res: Response) => {
  try {
    const companyId = Number(req.query.companyId); // ← 로그인된 업체 ID
    const page = Math.max(1, parseInt(String(req.query.page ?? '1'), 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(String(req.query.pageSize ?? '20'), 10) || 20));
    const offset = (page - 1) * pageSize;

    // 검색/필터 (선택)
    const q = String(req.query.q ?? '').trim();
    const statusFront = (req.query.status ?? '').toString().trim() as ''|'NEW'|'ASSIGNED'|'IN_PROGRESS'|'DONE'|'AS_REQUESTED'|'CANCELLED';

    const whereSR: any = {};
    if (q) {
      whereSR[Op.or] = [
        { org_name: { [Op.like]: `%${q}%` } },
        { contact_name: { [Op.like]: `%${q}%` } },
        { address: { [Op.like]: `%${q}%` } },
      ];
    }
    if (statusFront) {
      whereSR.status = statusFront;
    }

    const { rows, count } = await ServiceRequest.findAndCountAll({
      where: whereSR,
      include: [
        // ✅ 이 조인 덕분에 "내 회사로 배정된" 신청만 남음
        {
          model: Assignment,
          as: 'assignments',
          required: true, // ← INNER JOIN
          where: {
            company_id: companyId,
            status: { [Op.ne]: 'DECLINED' }, // ← 거절 배정 제외
          },
          attributes: [], // ← 결과에 Assignment 컬럼 안 보여주고 필터만
          // paranoid: true, // 기본값이라 소프트삭제된 배정은 자동 제외
        },
        // 필요하면 신청자/회사 추가 정보도 가져오기
        { model: User, as: 'creator', attributes: ['id','name','email'] },
      ],
      distinct: true,     // ← JOIN 중복으로 count/rows 꼬임 방지
      subQuery: false,    // ← 페이징 성능 개선(대량 데이터일 때 도움)
      order: [['createdAt', 'DESC']],
      offset,
      limit: pageSize,
    });

    res.json({
      is_success: true,
      page,
      pageSize,
      totalCount: count,
      items: rows,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ is_success: false, message: 'Server error' });
  }
});



export default router;