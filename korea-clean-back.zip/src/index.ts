
import express from "express";
import cors from 'cors';
import cookieParser from 'cookie-parser';
import bodyParser from 'body-parser';
import dotenv from 'dotenv'; 
import users from './routes/users';
import auth from './routes/auth';
import request from './routes/request';
import inquiry from './routes/inquiry';

import company from './routes/company';
const db = require("../models");   
dotenv.config(); // ✅ .env 로드 
const app = express();
const PORT = 4500; 


// CORS 설정
const corsOptions = {
  //origin: process.env.FRONTEND_ORIGIN || 'http://localhost:3000',  // 프론트엔드 주소 명확히 지정
  origin: ['http://localhost:3000', 'http://113.131.151.103:3000','http://113.131.151.103:8088'], // 실제 FE 오리진
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'], 
};
app.use(bodyParser.json()); 
app.use(cookieParser()); 
//웹 허용여부 
app.use(cors(corsOptions));
app.use(express.json());  
// (선택) URL-encoded 폼 데이터 파서 추가
app.use(express.urlencoded({ extended: false }));

app.use('/users',users);
app.use('/auth',auth);
app.use('/company',company);
app.use('/request',request);
app.use('/inquiry',inquiry);
//서버시작과 동시에 db 동기화 하기
db.sequelize.sync({ force:false})
    .then(()=>{
        console.log('데이터베이스 연결 성공') 
    })
    .catch((err:any)=>{
        console.error(err) 
    });
 app.use('/uploads',express.static('uploads')); 
// app.use('/sample',express.static('sample')); 


const server=app.listen(PORT,()=>{
    console.log(`서버실행 http://localhost:${PORT}`);
})

