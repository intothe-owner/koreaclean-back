// middleware/auth.ts
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export interface AuthRequest extends Request {
  auth?: { sub: number | string; role?: string };
}

export function auth(requiredRoles?: Array<'SUPER'|'ADMIN' | 'CLIENT' | 'COMPANY'>) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const bearer = req.headers.authorization;
      const fromHeader = bearer?.startsWith('Bearer ') ? bearer.split(' ')[1] : undefined;
      const fromCookie = req.cookies?.access_token as string | undefined;
      const token = fromHeader || fromCookie;
      if (!token) return res.status(401).json({ is_success: false, message: '인증 토큰이 필요합니다.' });

      const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET || 'dev-access') as any;
      req.auth = { sub: decoded.sub, role: decoded.role };

      if (requiredRoles?.length && !requiredRoles.includes(decoded.role)) {
        return res.status(403).json({ is_success: false, message: '권한이 없습니다.' });
      }
      next();
    } catch (e) {
      return res.status(401).json({ is_success: false, message: '유효하지 않은 토큰입니다.' });
    }
  };
}
