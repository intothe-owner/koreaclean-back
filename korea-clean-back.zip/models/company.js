const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
class Company extends Model {}
Company.init({
  id: { type: DataTypes.BIGINT.UNSIGNED, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING(150), allowNull: false },
  ceo: { type: DataTypes.STRING(100), allowNull: true },
  biz_no: { type: DataTypes.STRING(50), allowNull: true }, // 사업자등록번호
  phone: { type: DataTypes.STRING(50), allowNull: true },
  address: { type: DataTypes.STRING(255), allowNull: true },
  regions: { type: DataTypes.JSON, allowNull: true },      // 서비스 가능 지역 배열
  equipments: { type: DataTypes.JSON, allowNull: true },   // 보유 장비/인력 JSON
  certs: { type: DataTypes.JSON, allowNull: true },        // 자격증/경력 JSON
  documents: { type: DataTypes.JSON, allowNull: true },    // 업로드 서류 JSON (파일경로/원본명/사이즈 등)
  status: { // 'PENDING' | 'APPROVED' | 'REJECTED'
    type: DataTypes.ENUM('PENDING', 'APPROVED', 'REJECTED'),
    allowNull: false,
    defaultValue: 'PENDING',
  },
}, {
  sequelize,
  tableName: 'company',
  indexes: [{ fields: ['status'] }, { fields: ['name'] }],
  timestamps: true,           // createdAt/updatedAt 사용
  underscored: false,         // ⬅️ 스네이크 끄기 (중요)
  createdAt: 'createdAt',     // ⬅️ 명시적으로 카멜
  updatedAt: 'updatedAt',
  paranoid: true,            // deletedAt 안 쓰면 false
});

return Company;
}
