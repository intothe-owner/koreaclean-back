// src/models/chatRoom.js
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ChatRoom extends Model {}

  ChatRoom.init({
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: '채팅방 ID',
    },

    // 맥락: 서비스 신청 × 업체 (업체는 미배정이면 null 허용)
    service_request_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: 'FK → service_request.id',
    },
    company_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: true,
      comment: 'FK → company.id (미배정 시 NULL)',
    },

    title: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: '방 제목(선택)',
    },

    is_closed: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: '방 종료 여부',
    },

    created_by: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: '방 개설자 FK → user.id',
    },

    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
    deletedAt: { type: DataTypes.DATE, allowNull: true },
  }, {
    sequelize,
    tableName: 'chat_room',
    comment: '실시간 채팅 방',
    timestamps: true,
    paranoid: true,
    underscored: false,
    indexes: [
      { fields: ['service_request_id'] },
      { fields: ['company_id'] },
      { fields: ['is_closed'] },
      // 동일 조합 1개 방(UNIQUE)
      { unique: true, fields: ['service_request_id', 'company_id'] },
    ],
  });

  return ChatRoom;
};
