// src/models/chatMessageRead.js
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ChatMessageRead extends Model {}

  ChatMessageRead.init({
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: '읽음 레코드 ID',
    },

    room_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: 'FK → chat_room.id',
    },

    message_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: 'FK → chat_message.id',
    },

    user_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: '읽은 사람 FK → user.id',
    },

    read_at: {
      type: DataTypes.DATE,
      allowNull: false,
      comment: '읽은 시각',
      defaultValue: DataTypes.NOW,
    },

    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
    deletedAt: { type: DataTypes.DATE, allowNull: true },
  }, {
    sequelize,
    tableName: 'chat_message_read',
    comment: '메시지 읽음 영수증(선택)',
    timestamps: true,
    paranoid: true,
    underscored: false,
    indexes: [
      { fields: ['room_id'] },
      { fields: ['message_id'] },
      { fields: ['user_id'] },
      { unique: true, fields: ['message_id', 'user_id'] }, // 동일 메시지-유저 중복 방지
    ],
  });

  return ChatMessageRead;
};
