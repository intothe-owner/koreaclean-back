// src/models/chatMessage.js
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ChatMessage extends Model {}

  ChatMessage.init({
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: '메시지 ID',
    },

    room_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: 'FK → chat_room.id',
    },

    author_user_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: '발신자 FK → user.id',
    },

    type: {
      type: DataTypes.ENUM('TEXT', 'IMAGE', 'FILE', 'SYSTEM'),
      allowNull: false,
      defaultValue: 'TEXT',
      comment: '메시지 타입',
    },

    content: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: '본문(텍스트)',
    },

    // 파일/이미지 등 메타 (URL, 파일명 등)
    attachments: {
      type: DataTypes.JSON,
      allowNull: true,
      comment: '첨부 메타(JSON 배열 권장)',
    },

    is_edited: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: '수정 여부',
    },

    is_deleted: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: '삭제(소프트) 여부',
    },

    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
    deletedAt: { type: DataTypes.DATE, allowNull: true },
  }, {
    sequelize,
    tableName: 'chat_message',
    comment: '채팅 메시지',
    timestamps: true,
    paranoid: true,
    underscored: false,
    indexes: [
      { fields: ['room_id'] },
      { fields: ['author_user_id'] },
      { fields: ['createdAt'] }, // 시간순 페이징
    ],
  });

  return ChatMessage;
};
