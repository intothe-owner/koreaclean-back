// src/models/serviceRequest.js
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ServiceRequest extends Model {}

  ServiceRequest.init({
    id: { type: DataTypes.BIGINT.UNSIGNED, autoIncrement: true, primaryKey: true, comment: '서비스 신청 ID (PK)' },
    created_by: { type: DataTypes.BIGINT.UNSIGNED, allowNull: false, comment: '신청자 사용자 ID (FK→user.id)' },

    org_name: { type: DataTypes.STRING(150), allowNull: false, comment: '기관명' },
    contact_name: { type: DataTypes.STRING(100), allowNull: false, comment: '담당자 이름' },
    contact_phone: { type: DataTypes.STRING(50), allowNull: false, comment: '담당자 연락처' },
    contact_email: { type: DataTypes.STRING(191), allowNull: true, validate: { isEmail: true }, comment: '담당자 이메일' },
    address: { type: DataTypes.STRING(255), allowNull: false, comment: '현장 주소' },

    service_type: {
      type: DataTypes.ENUM('REGULAR_1W','REGULAR_2W','ONE_OFF','SPECIAL'),
      allowNull: false, comment: '서비스 유형(주1회/주2회/단건/특수)'
    },
    preferred_datetime: { type: DataTypes.DATE, allowNull: true, comment: '희망 일정' },
    details: { type: DataTypes.TEXT, allowNull: true, comment: '요청 상세 설명' },
    attachments: { type: DataTypes.JSON, allowNull: true, comment: '첨부 파일 JSON 배열 [{name,path,size,mime,meta}]' },

    status: {
      type: DataTypes.ENUM('NEW','ASSIGNED','IN_PROGRESS','DONE','AS_REQUESTED','CANCELLED'),
      allowNull: false, defaultValue: 'NEW', comment: '진행 상태'
    },
    rating: { type: DataTypes.INTEGER, allowNull: true, validate: { min: 1, max: 5 }, comment: '고객 평점(1~5)' },
    feedback: { type: DataTypes.TEXT, allowNull: true, comment: '고객 피드백' },
  }, {
    sequelize,
    tableName: 'service_request',
    comment: '기관의 서비스 신청 정보',
    indexes: [{ fields: ['status'] }, { fields: ['service_type'] }],
  });

  return ServiceRequest;
};
