// src/models/chatMember.js
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class ChatMember extends Model {}

  ChatMember.init({
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
      comment: '멤버 ID',
    },

    room_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: 'FK → chat_room.id',
    },

    user_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      comment: 'FK → user.id',
    },

    role: {
      type: DataTypes.ENUM('REQUESTER', 'COMPANY', 'ADMIN'),
      allowNull: false,
      defaultValue: 'REQUESTER',
      comment: '방 내 역할',
    },

    // 방 단위 읽음 포인터
    last_read_message_id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: true,
      comment: '마지막으로 읽은 메시지 ID',
    },
    last_read_at: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: '마지막 읽음 시각',
    },

    is_muted: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
      comment: '알림 끔 여부',
    },

    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
    deletedAt: { type: DataTypes.DATE, allowNull: true },
  }, {
    sequelize,
    tableName: 'chat_member',
    comment: '채팅방 멤버',
    timestamps: true,
    paranoid: true,
    underscored: false,
    indexes: [
      { fields: ['room_id'] },
      { fields: ['user_id'] },
      { unique: true, fields: ['room_id', 'user_id'] }, // 방-유저 1회 가입
    ],
  });

  return ChatMember;
};
