// src/models/index.js
const { Sequelize, DataTypes } = require('sequelize');
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.json')[env];

const sequelize = new Sequelize(config.database, config.username, config.password, {
  host: config.host,
  dialect: config.dialect,
  timezone: config.timezone,
  logging: (sql, timing) => console.log('[SQL]', sql),
  define: { underscored: true, paranoid: true, freezeTableName: true },
});

// 모델 로드 (모두 함수형 export)
const User           = require('./user')(sequelize, DataTypes);
const Company        = require('./company')(sequelize, DataTypes);
const ServiceRequest = require('./serviceRequest')(sequelize, DataTypes);
const Assignment     = require('./assignment')(sequelize, DataTypes);
const WorkReport     = require('./workReport')(sequelize, DataTypes);
const AfterService   = require('./afterService')(sequelize, DataTypes);
const Invoice        = require('./invoice')(sequelize, DataTypes); // ← 대소문자 주의(파일명과 동일)
const Inquiry         = require('./inquiry')(sequelize, DataTypes);
const ChatRoom        = require('./chatRoom')(sequelize, DataTypes);
const ChatMember      = require('./chatMember')(sequelize, DataTypes);
const ChatMessage     = require('./chatMessage')(sequelize, DataTypes);
const ChatMessageRead = require('./chatMessageRead')(sequelize, DataTypes);
// src/models/index.js (상단 모델 로드 부분에 추가)
const InquiryComment = require('./inquiryComment')(sequelize, DataTypes);

//
// 관계 정의 (모든 모델 init 이후에!)
//
//
// 관계 정의 (모든 모델 init 이후에!)
// (기존 Inquiry, User, Company, ServiceRequest 관계 아래에 이어서 붙이세요.)
//
//
// ===== 실시간 채팅 관계 =====
// ChatRoom ↔ ServiceRequest / Company / User(creator)
ChatRoom.belongsTo(ServiceRequest, {
  foreignKey: { name: 'service_request_id', allowNull: false },
  as: 'serviceRequest',
});
ServiceRequest.hasMany(ChatRoom, {
  foreignKey: { name: 'service_request_id', allowNull: false },
  as: 'chatRooms',
});

ChatRoom.belongsTo(Company, {
  foreignKey: { name: 'company_id', allowNull: true },
  as: 'company',
});
Company.hasMany(ChatRoom, {
  foreignKey: { name: 'company_id', allowNull: true },
  as: 'chatRooms',
});

ChatRoom.belongsTo(User, {
  foreignKey: { name: 'created_by', allowNull: false },
  as: 'creator',
});
User.hasMany(ChatRoom, {
  foreignKey: { name: 'created_by', allowNull: false },
  as: 'createdChatRooms',
});

// ChatMember ↔ ChatRoom / User
ChatMember.belongsTo(ChatRoom, {
  foreignKey: { name: 'room_id', allowNull: false },
  as: 'room',
});
ChatRoom.hasMany(ChatMember, {
  foreignKey: { name: 'room_id', allowNull: false },
  as: 'members',
});

ChatMember.belongsTo(User, {
  foreignKey: { name: 'user_id', allowNull: false },
  as: 'user',
});
User.hasMany(ChatMember, {
  foreignKey: { name: 'user_id', allowNull: false },
  as: 'chatMemberships',
});

// ChatMessage ↔ ChatRoom / User(author)
ChatMessage.belongsTo(ChatRoom, {
  foreignKey: { name: 'room_id', allowNull: false },
  as: 'room',
});
ChatRoom.hasMany(ChatMessage, {
  foreignKey: { name: 'room_id', allowNull: false },
  as: 'messages',
});

ChatMessage.belongsTo(User, {
  foreignKey: { name: 'author_user_id', allowNull: false },
  as: 'author',
});
User.hasMany(ChatMessage, {
  foreignKey: { name: 'author_user_id', allowNull: false },
  as: 'chatMessages',
});

// ChatMessageRead (선택)
// 읽음: 메시지/유저/룸
ChatMessageRead.belongsTo(ChatMessage, {
  foreignKey: { name: 'message_id', allowNull: false },
  as: 'message',
});
ChatMessage.hasMany(ChatMessageRead, {
  foreignKey: { name: 'message_id', allowNull: false },
  as: 'reads',
});

ChatMessageRead.belongsTo(User, {
  foreignKey: { name: 'user_id', allowNull: false },
  as: 'reader',
});
User.hasMany(ChatMessageRead, {
  foreignKey: { name: 'user_id', allowNull: false },
  as: 'messageReads',
});

ChatMessageRead.belongsTo(ChatRoom, {
  foreignKey: { name: 'room_id', allowNull: false },
  as: 'room',
});
ChatRoom.hasMany(ChatMessageRead, {
  foreignKey: { name: 'room_id', allowNull: false },
  as: 'messageReads',
});
// Inquiry ↔ InquiryComment (1:N)
Inquiry.hasMany(InquiryComment, {
  foreignKey: { name: 'inquiry_id', allowNull: false },
  as: 'comments',
});
InquiryComment.belongsTo(Inquiry, {
  foreignKey: { name: 'inquiry_id', allowNull: false },
  as: 'inquiry',
});

// User ↔ InquiryComment (1:N) — 작성자
User.hasMany(InquiryComment, {
  foreignKey: { name: 'author_user_id', allowNull: false },
  as: 'inquiryComments',
});
InquiryComment.belongsTo(User, {
  foreignKey: { name: 'author_user_id', allowNull: false },
  as: 'author',
});

// InquiryComment ↔ InquiryComment (self, 1:N) — 대댓글
InquiryComment.hasMany(InquiryComment, {
  foreignKey: { name: 'parent_id', allowNull: true },
  as: 'children',
});
InquiryComment.belongsTo(InquiryComment, {
  foreignKey: { name: 'parent_id', allowNull: true },
  as: 'parent',
});

// Inquiry ↔ User(문의 등록자)
Inquiry.belongsTo(User, {
  foreignKey: { name: 'requester_user_id', allowNull: false },
  as: 'requester',
});
User.hasMany(Inquiry, {
  foreignKey: { name: 'requester_user_id', allowNull: false },
  as: 'inquiriesAsRequester',
});

// Inquiry ↔ Company(문의 대상 업체; 선택)
Inquiry.belongsTo(Company, {
  foreignKey: { name: 'company_id', allowNull: true },
  as: 'company',
});
Company.hasMany(Inquiry, {
  foreignKey: { name: 'company_id', allowNull: true },
  as: 'inquiries',
});

// Inquiry ↔ ServiceRequest(맥락 연결; 선택)
Inquiry.belongsTo(ServiceRequest, {
  foreignKey: { name: 'service_request_id', allowNull: true },
  as: 'serviceRequest',
});
ServiceRequest.hasMany(Inquiry, {
  foreignKey: { name: 'service_request_id', allowNull: true },
  as: 'inquiries',
});


// 1) User ↔ Company
User.hasOne(Company, { foreignKey: { name: 'owner_user_id', allowNull: true }, as: 'company' });
Company.belongsTo(User, { foreignKey: { name: 'owner_user_id', allowNull: true }, as: 'owner' });

// 2) User(신청자) ↔ ServiceRequest
User.hasMany(ServiceRequest, { foreignKey: { name: 'created_by', allowNull: false }, as: 'serviceRequests' });
ServiceRequest.belongsTo(User, { foreignKey: { name: 'created_by', allowNull: false }, as: 'creator' });

// 3) ServiceRequest ↔ Assignment ↔ Company
ServiceRequest.hasMany(Assignment, { foreignKey: { name: 'service_request_id', allowNull: false }, as: 'assignments' });
Assignment.belongsTo(ServiceRequest, { foreignKey: { name: 'service_request_id', allowNull: false }, as: 'serviceRequest' });

Company.hasMany(Assignment, { foreignKey: { name: 'company_id', allowNull: false }, as: 'assignments' });
Assignment.belongsTo(Company, { foreignKey: { name: 'company_id', allowNull: false }, as: 'company' });

// 배정자(관리자) 추적
User.hasMany(Assignment, { foreignKey: { name: 'assigned_by', allowNull: true }, as: 'works' });
Assignment.belongsTo(User, { foreignKey: { name: 'assigned_by', allowNull: true }, as: 'assigner' });

// 4) ServiceRequest ↔ WorkReport (회사 기준)
ServiceRequest.hasMany(WorkReport, { foreignKey: { name: 'service_request_id', allowNull: false }, as: 'workReports' });
WorkReport.belongsTo(ServiceRequest, { foreignKey: { name: 'service_request_id', allowNull: false }, as: 'serviceRequest' });

Company.hasMany(WorkReport, { foreignKey: { name: 'company_id', allowNull: false }, as: 'workReports' });
WorkReport.belongsTo(Company, { foreignKey: { name: 'company_id', allowNull: false }, as: 'company' });

// (선택) Assignment 1:1 WorkReport
Assignment.hasOne(WorkReport, { foreignKey: { name: 'assignment_id', allowNull: true }, as: 'report' });
WorkReport.belongsTo(Assignment, { foreignKey: { name: 'assignment_id', allowNull: true }, as: 'assignment' });

// 5) ServiceRequest ↔ AfterService
ServiceRequest.hasMany(AfterService, { foreignKey: { name: 'service_request_id', allowNull: true }, as: 'afterServices' });
AfterService.belongsTo(ServiceRequest, { foreignKey: { name: 'service_request_id', allowNull: true }, as: 'serviceRequest' });

// 6) ServiceRequest ↔ Invoice (MVP 1:1 가정)
ServiceRequest.hasOne(Invoice, { foreignKey: { name: 'service_request_id', allowNull: false }, as: 'invoice' });
Invoice.belongsTo(ServiceRequest, { foreignKey: { name: 'service_request_id', allowNull: false }, as: 'serviceRequest' });

// 회사 단위 정산 조회
Company.hasMany(Invoice, { foreignKey: { name: 'company_id', allowNull: false }, as: 'invoices' });
Invoice.belongsTo(Company, { foreignKey: { name: 'company_id', allowNull: false }, as: 'company' });

module.exports = {
  sequelize,
  Sequelize, // 필요시 외부에서 타입/연결 검사용
  User,
  Company,
  ServiceRequest,
  Assignment,
  WorkReport,
  AfterService,
  Invoice,
  Inquiry,
  InquiryComment
};
