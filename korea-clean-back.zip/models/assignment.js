const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {

class Assignment extends Model {}
Assignment.init({
  id: {
    type: DataTypes.BIGINT.UNSIGNED,
    autoIncrement: true,
    primaryKey: true,
    comment: '배정 ID (PK)',
  },
  status: {
    // 'ASSIGNED' | 'ACCEPTED' | 'DECLINED' | 'IN_PROGRESS' | 'DONE'
    type: DataTypes.ENUM('ASSIGNED','ACCEPTED','DECLINED','IN_PROGRESS','DONE'),
    allowNull: false,
    defaultValue: 'ASSIGNED',
    comment: '배정 상태',
  },
  assigned_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
    comment: '배정 시각',
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: '배정 관련 비고/메모',
  },
}, {
  sequelize,
  tableName: 'assignment',
  comment: '서비스 신청에 대한 업체 배정 내역',
  indexes: [
    { fields: ['status'] },
  ],
  timestamps: true,           // createdAt/updatedAt 사용
  underscored: false,         // ⬅️ 스네이크 끄기 (중요)
  createdAt: 'createdAt',     // ⬅️ 명시적으로 카멜
  updatedAt: 'updatedAt',
  paranoid: true,            // deletedAt 안 쓰면 false
});

return Assignment;
}